/* Defines for polled kiss support ala G8BPQ for JNOS */
  
void kiss_poller __ARGS((int xdev,void *p1,void *p2));
  
